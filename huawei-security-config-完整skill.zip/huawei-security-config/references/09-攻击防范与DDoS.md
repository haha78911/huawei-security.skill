# 09 · 攻击防范与 DDoS

> 分两类：① 防火墙内置**单包攻击/扫描窥探防范**与**流量型攻击（Flood）防护**；② 专业 **Anti-DDoS 检测+清洗**设备（检测、引流、清洗、回注）。

## 目录
1. 单包攻击防范（firewall defend）
2. 扫描 / 窥探防范与黑名单
3. 流量型 Flood 攻击防范
4. 黑白名单
5. 专业 Anti-DDoS（检测/清洗/引流/回注）
6. 验证与排障

---

## 1. 单包攻击防范（firewall defend）

```text
[FW] firewall defend ip-spoofing enable      # IP 欺骗
[FW] firewall defend teardrop enable        # Teardrop 分片攻击
[FW] firewall defend smurf enable           # Smurf（ICMP 广播放大）
[FW] firewall defend land enable            # Land（源目地址相同）
[FW] firewall defend fraggle enable         # Fraggle（UDP 广播放大）
[FW] firewall defend ping-of-death enable   # 死亡之 Ping（超大 ICMP）
[FW] firewall defend large-icmp enable
[FW] firewall defend large-icmp max-length 4000
[FW] firewall defend icmp-unreachable enable
[FW] firewall defend icmp-redirect enable
[FW] firewall defend tracert enable
```

> USG6000V（eNSP）用 `firewall defend ...`；新版 USG V500 部分命令位于攻击防范策略/profile，命令以版本为准。默认很多单包防护已开启。

## 2. 扫描 / 窥探防范与黑名单

```text
# IP 地址扫描（ip-sweep）
[FW] firewall defend ip-sweep enable
[FW] firewall defend ip-sweep max-rate 4000          # 每秒最大 ICMP 请求
[FW] firewall defend ip-sweep blacklist-timeout 20    # 攻击源加入黑名单时长(分钟)
# 端口扫描（port-scan）
[FW] firewall defend port-scan enable
[FW] firewall defend port-scan max-rate 4000
[FW] firewall defend port-scan blacklist-timeout 20
[FW] firewall defend action discard                   # 命中后丢弃
[FW] firewall blacklist enable                        # 使能黑名单
```

## 3. 流量型 Flood 攻击防范

SYN Flood、UDP Flood、HTTP Flood（CC）等流量型攻击，通过流量统计阈值 + 源认证（TCP 代理/重定向/验证码）防护：

```text
# 接口使能流量统计
[FW] interface GigabitEthernet 0/0/1
[FW-GigabitEthernet0/0/1] anti-ddos flow-statistic enable
# HTTP Flood 源检测与告警阈值
[FW] anti-ddos http-flood source-detect mode basic      # basic/advanced/redirect
[FW] anti-ddos http-flood defend alert-rate 100
```

- SYN Flood 常用 TCP 代理/源认证（SYN Cookie）；HTTP Flood 用重定向/验证码甄别真实浏览器。
- 阈值需结合正常基线设置，过低误伤、过高漏防。

## 4. 黑白名单

```text
[FW] firewall blacklist enable
[FW] firewall blacklist item source-ip 1.1.1.1   # 手动加入黑名单（timeout 可设时长）
# 白名单优先放行可信地址（视版本命令）
```

扫描/Flood 命中后可自动把攻击源加入黑名单（见 blacklist-timeout）。

## 5. 专业 Anti-DDoS（检测/清洗/引流/回注）

用于运营商/数据中心大流量防护，由 **检测设备（Detect）、清洗设备（Clean）、管理中心（ATIC）** 组成：

- **工作模式与检测/清洗接口**：

```text
# 指定检测 SPU（检测设备）
[Detect] firewall ddos detect-spu slot 0 cpu 0
# 接口使能检测 / 清洗 / 流量统计
[Detect-GE0/0/0] anti-ddos detect enable
[Detect-GE0/0/0] anti-ddos flow-statistic enable
[Clean-GE0/0/1] anti-ddos clean enable
[Clean-GE0/0/1] anti-ddos flow-statistic enable
```

- **引流（把可疑流量送到清洗设备）与回注（清洗后送回网络）**，两种方式：
  - BGP 引流：清洗设备与引流路由器建 iBGP，发布被攻击网段的明细/下一跳路由（`import-route op-route`、`route-policy ... apply community no-advertise`、`firewall ddos bgp-next-hop ...`）。
  - 策略路由/MQC 引流：`traffic classifier` + `traffic behavior redirect ip-nexthop <清洗设备>` + `traffic-policy`；回注用 `policy-based-route` 的 `action pbr egress-interface ...`。
- 防护策略（各 Flood/单包/应用层阈值与动作）通常在 ATIC 管理中心配置后下发设备。

## 6. 验证与排障

```text
<FW> display firewall defend state            # 各项攻击防范开关
<FW> display firewall blacklist item          # 黑名单
<FW> display firewall statistics system       # 攻击/丢包统计
<AntiDDoS> display anti-ddos flow-statistic   # 流量统计
<AntiDDoS> display bgp routing-table op-route # 引流路由
<AntiDDoS> display policy-based-route         # 回注策略
```

**常见问题**：
- 正常流量被误拦：检查扫描/Flood 阈值是否过低、是否被自动加入黑名单；调大阈值或加白名单。
- Anti-DDoS 引流不生效：BGP 邻居状态、引流路由是否发布/优先级、`detect-spu` 是否指定；回注不通检查策略路由与回注接口。
