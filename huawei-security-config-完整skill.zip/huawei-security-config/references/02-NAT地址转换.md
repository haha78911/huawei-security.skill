# 02 · NAT 地址转换（USG 防火墙 / VRP 路由器）

## 目录
1. NAT 类型与命令体系
2. NAT 地址组
3. 源 NAT（内网访问外网）
4. NAT Server（发布内网服务器）
5. 目的 NAT / 双向 NAT
6. 三元组 NAT 与 Server-map
7. NAT 与安全策略配合
8. 验证与排障

---

## 1. NAT 类型与命令体系

| 类型 | 作用 | 典型命令 |
|---|---|---|
| 源 NAT-静态 | 私网地址一对一固定映射公网地址 | `nat static global ... inside ...` |
| 源 NAT-NAPT | 多私网地址复用公网地址（地址+端口转换，主流） | `nat-policy` + `action source-nat address-group` |
| Easy IP | 直接复用出接口公网 IP 做 NAPT | `nat outbound <acl>`（路由器） |
| NAT Server | 把公网 IP:端口映射到内网服务器（目的转换） | `nat server ... global ... inside ...` |
| 目的 NAT | 重写报文目的地址（负载分担/重定向） | `action destination-nat ...` |
| 双向 NAT | 同时转换源和目的 | nat-policy 中源/目的转换组合 |

- **新版 USG（V500/V600）**：统一在 `nat-policy` 下用规则 + 地址组实现，与安全策略写法一致。
- **路由器 VRP / 老 USG**：在出接口用 `nat outbound`、`nat static`、`nat server`，配合 ACL/地址组。

## 2. NAT 地址组

```text
[FW] nat address-group group1
[FW-address-group-group1] mode pat                 # pat=NAPT（端口复用）；no-pat=只转地址
[FW-address-group-group1] section 0 1.1.1.10 1.1.1.15   # 公网地址段
[FW-address-group-group1] route enable            # 生成黑洞/指向路由，防止路由环路
[FW-address-group-group1] quit
```

## 3. 源 NAT（内网访问外网）——新版 nat-policy

```text
# 地址组
[FW] nat address-group group1
[FW-address-group-group1] mode pat
[FW-address-group-group1] section 0 1.1.1.10 1.1.1.15
[FW-address-group-group1] route enable
[FW-address-group-group1] quit
# NAT 策略
[FW] nat-policy
[FW-policy-nat] rule name source_nat
[FW-policy-nat-rule-source_nat] source-zone trust
[FW-policy-nat-rule-source_nat] destination-zone untrust
[FW-policy-nat-rule-source_nat] source-address 10.1.1.0 24
[FW-policy-nat-rule-source_nat] action source-nat address-group group1
[FW-policy-nat-rule-source_nat] quit
```

路由器/老命令等价：

```text
[R] nat address-group 1 1.1.1.254 1.1.1.254
[R] acl 2000
[R-acl-basic-2000] rule permit source 192.168.1.0 0.0.0.255
[R-acl-basic-2000] quit
[R] interface GigabitEthernet 0/0/1
[R-GigabitEthernet0/0/1] nat outbound 2000 address-group 1   # Easy IP: nat outbound 2000
```

静态一对一（接口/全局）：

```text
[R] interface GigabitEthernet 0/0/1
[R-GigabitEthernet0/0/1] nat static enable
[R-GigabitEthernet0/0/1] nat static global 1.1.1.10 inside 192.168.1.1
```

## 4. NAT Server（发布内网服务器）

把公网地址的端口映射到 DMZ/内网服务器（最常用于发布 Web/FTP）：

```text
[FW] nat server policy_web protocol tcp global 1.1.1.10 www inside 10.2.0.8 www
# 不区分端口/协议的整体映射
[FW] nat server global 1.1.1.10 inside 10.2.0.8
# FTP（多通道，需配合 ASPF）
[FW] nat server policy_ftp protocol tcp global 1.1.1.10 ftp inside 10.2.0.8 ftp no-reverse
[FW] firewall interzone dmz untrust
[FW-interzone-dmz-untrust] detect ftp
[FW-interzone-dmz-untrust] quit
```

- `no-reverse`：不生成反向映射；`www`=80、`ftp`=21 等为端口别名，也可写数字端口。
- NAT Server 会自动生成 Server-map 表项。

## 5. 目的 NAT / 双向 NAT（新版 nat-policy）

```text
# 目的地址池
[FW] destination-nat address-group group1
[FW-dnat-address-group-group1] section 10.2.0.7 10.2.0.8
[FW-dnat-address-group-group1] quit
# 目的 NAT 规则
[FW] nat-policy
[FW-policy-nat] rule name dnat_http
[FW-policy-nat-rule-dnat_http] source-zone untrust
[FW-policy-nat-rule-dnat_http] destination-address 1.1.10.10 1.1.10.11
[FW-policy-nat-rule-dnat_http] service http
[FW-policy-nat-rule-dnat_http] action destination-nat static address-to-address address-group group1
[FW-policy-nat-rule-dnat_http] quit
```

## 6. 三元组 NAT 与 Server-map

- 三元组 NAT（NAPT 基础上放宽）：转换后外部可主动访问，生成含「协议+转换后地址+端口」的 **Server-map**，适合 P2P/部分游戏。
- 地址组相关开关：`mode pat`、`triplet enable`（视版本）；查看 `display firewall server-map`。

## 7. NAT 与安全策略配合（关键易错点）

安全策略对 **NAT 处理后的地址**还是原始地址匹配，随版本方向不同；USG 新版规则：

- **源 NAT（内网出外网）**：安全策略匹配**原始私网源地址**，放行 trust→untrust 即可。
- **NAT Server / 目的 NAT（外网进内网）**：安全策略匹配**转换后的私网目的地址**，需放行 untrust→dmz、目的地址为内网服务器地址：

```text
[FW] security-policy
[FW-policy-security] rule name untrust_dmz_web
[FW-policy-security-rule-untrust_dmz_web] source-zone untrust
[FW-policy-security-rule-untrust_dmz_web] destination-zone dmz
[FW-policy-security-rule-untrust_dmz_web] destination-address 10.2.0.0 24
[FW-policy-security-rule-untrust_dmz_web] service http
[FW-policy-security-rule-untrust_dmz_web] action permit
[FW-policy-security-rule-untrust_dmz_web] quit
```

> 若策略不生效，优先确认匹配的是转换前还是转换后地址（不同 V/R 版本有差异），用命中计数验证。

## 8. 验证与排障

```text
<FW> display nat-policy rule all               # NAT 规则及命中
<FW> display nat address-group                 # 地址组与分配
<FW> display firewall session table            # 会话（看 NAT 前后地址，[ ] 内为转换值）
<FW> display firewall server-map               # Server-map（NAT Server/三元组/ASPF）
[FW] diagnose
[FW-diagnose] display firewall statistic acl   # NAT/ACL 命中统计
```

- 会话显示形如 `10.1.1.1:43982[1.1.1.10/2048]-->2.2.2.2:80`，方括号内即转换后地址端口。
- **不通排查顺序**：① NAT 规则命中计数是否增长；② 地址组地址是否用尽；③ 安全策略是否放行（注意转换前后地址）；④ FTP/SIP 等是否启用 ASPF/ALG；⑤ 回程路由是否可达。
