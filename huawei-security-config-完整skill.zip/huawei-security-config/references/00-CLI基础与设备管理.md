# 00 · CLI 基础与设备管理（华为 VRP / USG 防火墙通用）

> 适用于华为 USG 系列防火墙及运行 VRP 的交换机/路由器。防火墙管理员账号用 `manager-user`，交换机/路由器用 `local-user`。

## 目录
1. 命令视图体系
2. 命令行编辑基础
3. 命名、时钟与接口
4. 查看与保存配置
5. 登录管理（Console / Telnet / SSH）
6. 管理员账户与权限
7. 接口访问控制 service-manage
8. 文件与启动管理

---

## 1. 命令视图体系

| 视图 | 提示符示例 | 进入 / 退出 |
|---|---|---|
| 用户视图 | `<FW>` | 登录后默认；`quit` 断开 |
| 系统视图 | `[FW]` | 用户视图下 `system-view`；`quit` 回用户视图 |
| 接口视图 | `[FW-GigabitEthernet0/0/1]` | 系统视图下 `interface GigabitEthernet 0/0/1` |
| 安全区域视图 | `[FW-zone-trust]` | `firewall zone trust` |
| 安全策略视图 | `[FW-policy-security]` | `security-policy` |
| AAA 视图 | `[FW-aaa]` | `aaa` |
| 诊断视图 | `[FW-diagnose]` | `diagnose`（排障用） |

- `quit`：退回上一级视图；`return` 或快捷键 `Ctrl+Z`：从任意视图直接回用户视图。
- 视图提示符随设备名变化，先 `sysname` 改名后提示符同步更新。

## 2. 命令行编辑基础

- `?`：获取帮助。`?` 列出当前视图全部命令；关键字后接 `?`（如 `dis?`）列出可配关键字。
- `Tab`：补全关键字；输入不冲突的前缀可直接回车执行（简写）。
- 错误提示：`^` 定位错误位置；`Error: Unrecognized command` 表示命令无法识别。
- 常用快捷键：`Ctrl+Z` 回用户视图；`Ctrl+A` 光标到行首；`Ctrl+E` 到行尾；`?` 帮助。

## 3. 命名、时钟与接口

```text
<FW> system-view
[FW] sysname FW1                          # 命名设备
[FW1] clock timezone BJ add 8            # 设置时区（东八区）
[FW1] clock datetime 12:00:00 2026-10-10 # 设置当前时间
# 接口配置 IP（三层口）
[FW1] interface GigabitEthernet 0/0/1
[FW1-GigabitEthernet0/0/1] ip address 10.1.2.1 255.255.255.0
[FW1-GigabitEthernet0/0/1] undo shutdown # 启用接口（缺省多为 up）
```

掩码也可用长度写法：`ip address 10.1.2.1 24`。

## 4. 查看与保存配置

```text
[FW] display current-configuration       # 查看当前运行配置（任意视图可执行）
[FW] display saved-configuration         # 查看已保存配置
<FW> save                                # 保存当前配置到配置文件（在用户视图）
[FW] display this                        # 查看当前视图下的配置
[FW] display startup                     # 查看本次/下次启动的系统软件与配置文件
```

> 配置改动只在运行态生效，**必须 `save` 才会在重启后保留**。

## 5. 登录管理

### 5.1 Console 口（本地，缺省开放）

```text
[FW] user-interface console 0
[FW-ui-console0] authentication-mode password       # 或 aaa
[FW-ui-console0] set authentication password cipher Huawei@123
[FW-ui-console0] idle-timeout 5 0                   # 超时分钟 秒；0 表示永不超时
```

### 5.2 Telnet（明文，不推荐，实验常用）

```text
<FW> system-view
[FW] telnet server enable                            # 使能 Telnet 服务
[FW] user-interface vty 0 4
[FW-ui-vty0-4] authentication-mode aaa
[FW-ui-vty0-4] protocol inbound telnet
[FW-ui-vty0-4] user privilege level 3
[FW-ui-vty0-4] quit
[FW] aaa
[FW-aaa] manager-user telnetuser                     # 防火墙；交换机用 local-user
[FW-aaa-manager-use-telnetuser] password cipher Huawei@123
[FW-aaa-manager-use-telnetuser] service-type telnet
[FW-aaa-manager-use-telnetuser] level 3
[FW-aaa-manager-use-telnetuser] quit
```

### 5.3 STelnet/SSH（加密，推荐）

```text
<FW> system-view
[FW] stelnet server enable                           # 使能 STelnet 服务
[FW] rsa local-key-pair create                       # 生成本地 RSA 主机密钥（一路回车）
[FW] user-interface vty 0 4
[FW-ui-vty0-4] authentication-mode aaa
[FW-ui-vty0-4] protocol inbound ssh
[FW-ui-vty0-4] quit
[FW] ssh user sshuser authentication-type password   # 指定 SSH 用户及认证方式
[FW] aaa
[FW-aaa] manager-user sshuser
[FW-aaa-manager-use-sshuser] password cipher Huawei@123
[FW-aaa-manager-use-sshuser] service-type ssh
[FW-aaa-manager-use-sshuser] level 3
[FW-aaa-manager-use-sshuser] quit
```

公钥认证时：`ssh user <名> authentication-type rsa`，并通过 `ssh user <名> assign rsa-key <密钥名>` 绑定公钥。

## 6. 管理员账户与权限

```text
[FW] aaa
[FW-aaa] manager-user admin
[FW-aaa-manager-use-admin] password cipher Admin@123
[FW-aaa-manager-use-admin] service-type telnet ssh web  # 允许的接入方式
[FW-aaa-manager-use-admin] level 15                     # 管理员级别（0-15，15 最高）
[FW-aaa-manager-use-admin] quit
[FW-aaa] bind manager-user admin role system-admin      # 绑定角色（新版）
```

- 级别（`level`）：参观 0 / 监控 1 / 配置 2 / 管理 3（防火墙常用 0-3 或 0-15，视版本）。
- 交换机/路由器等价命令：`aaa` → `local-user <名> password cipher <密码>` → `local-user <名> service-type ssh` → `local-user <名> privilege level 15`。

## 7. 接口访问控制 service-manage（防火墙）

控制到防火墙本身（Local 区域）的管理流量，默认接口可能禁止管理协议：

```text
[FW] interface GigabitEthernet 0/0/1
[FW-GigabitEthernet0/0/1] service-manage enable
[FW-GigabitEthernet0/0/1] service-manage https permit
[FW-GigabitEthernet0/0/1] service-manage ssh permit
[FW-GigabitEthernet0/0/1] service-manage telnet permit
[FW-GigabitEthernet0/0/1] quit
```

> 登录防火墙本身还需放行 对端区域→`local` 的安全策略（见 01）。

## 8. 文件与启动管理

```text
<FW> dir                                # 列出存储介质文件
<FW> save                               # 保存配置
<FW> startup saved-configuration vrpcfg.zip   # 指定下次启动配置文件
<FW> startup system-software xxx.cc     # 指定下次启动系统软件（谨慎）
<FW> reset saved-configuration          # 清除已保存配置（恢复出厂前置操作，谨慎）
<FW> reboot                             # 重启
```

升级方式：通过 FTP/SFTP 上传系统软件 `.cc` 后 `startup system-software` 指定并 `reboot`；防火墙多采用 Web 一键升级或 U 盘/ BootWare 菜单升级。

---

## 常用排障命令

| 命令 | 作用 |
|---|---|
| `display version` | 版本、运行时间、主控/单板信息 |
| `display device` | 设备硬件与单板状态 |
| `display interface brief` | 接口状态与错包概览 |
| `display ip interface brief` | 三层接口 IP 与状态 |
| `display current-configuration` | 当前配置 |
| `display logbuffer` | 日志缓冲 |
