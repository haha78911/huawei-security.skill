# 06 · 用户管理、AAA 与网络准入控制 NAC

> **AAA**（认证 Authentication、授权 Authorization、计费 Accounting）决定"是谁、能做什么、如何记账"；**NAC** 通过 802.1X / Portal / MAC 三种方式对接入终端做准入控制。

## 目录
1. AAA 方案与本地用户
2. RADIUS / HWTACACS
3. 域 Domain
4. NAC 统一机制（authentication-profile）
5. 802.1X 认证
6. Portal 认证（交换机外置 / 防火墙内置）
7. MAC 认证
8. 免认证规则
9. 验证与排障

---

## 1. AAA 方案与本地用户

```text
[SW] aaa
[SW-aaa] authentication-scheme a1
[SW-aaa-authen-a1] authentication-mode local       # local/radius/hwtacacs
[SW-aaa-authen-a1] quit
[SW-aaa] authorization-scheme b1
[SW-aaa-author-b1] authorization-mode local
[SW-aaa-author-b1] quit
# 本地用户（交换机/路由器）
[SW-aaa] local-user user1 password cipher Huawei@123
[SW-aaa] local-user user1 service-type ssh        # ssh/telnet/8021x/portal...
[SW-aaa] local-user user1 privilege level 15
[SW-aaa] quit
```

防火墙管理员用 `manager-user`（见 00）；认证接入用户（NAC）用 `local-access-user`（见 6.2）。

## 2. RADIUS / HWTACACS

```text
[SW] radius-server template test
[SW-radius-test] radius-server authentication 172.21.10.78 1812 source ip-address 172.21.10.61
[SW-radius-test] radius-server accounting 172.21.10.78 1813
[SW-radius-test] radius-server shared-key cipher Huawei@123   # 须与服务器一致
[SW-radius-test] radius-attribute nas-ip 172.21.10.61
[SW-radius-test] quit
# 授权（CoA，需要时）
[SW] radius-server authorization 172.21.10.78 shared-key cipher Huawei@123
```

- 标准端口：认证 1812、计费 1813（老设备 1645/1646）。
- HWTACACS（命令行授权/审计，视版本）：`hwtacacs-server template <名>`，配置 `hwtacacs-server authentication/authorization/accounting <ip> <端口>` 与 `hwtacacs-server shared-key`。

## 3. 域 Domain

域把 AAA 方案与服务器模板组合，用户 `user@domain` 归属对应域：

```text
[SW] aaa
[SW-aaa] domain huawei.com
[SW-aaa-domain-huawei.com] authentication-scheme a1
[SW-aaa-domain-huawei.com] authorization-scheme b1
[SW-aaa-domain-huawei.com] accounting-scheme c1
[SW-aaa-domain-huawei.com] radius-server test
[SW-aaa-domain-huawei.com] quit
# 修改缺省域
[SW-aaa] domain default
[SW-aaa-domain-default] authentication-scheme radius
[SW-aaa-domain-default] radius-server Campus
```

## 4. NAC 统一机制（authentication-profile）

NAC 三类接入共用 **authentication-profile（认证模板）**：模板内绑定对应的接入模板（dot1x/portal/mac）和域，最后在接口（或 WLAN VAP）下引用。

```text
# 通用骨架
[SW] authentication-profile name p1
[SW-authen-profile-p1] dot1x-access-profile d1     # 或 portal/mac-access-profile
[SW-authen-profile-p1] access-domain huawei.com force
[SW-authen-profile-p1] quit
[SW] interface GigabitEthernet 0/0/1
[SW-GigabitEthernet0/0/1] authentication-profile p1
[SW-GigabitEthernet0/0/1] quit
```

## 5. 802.1X 认证

```text
# 1) 802.1X 接入模板
[SW] dot1x-access-profile name dot1x
[SW-dot1x-access-profile-dot1x] dot1x authentication-method eap   # eap/pap/chap
[SW-dot1x-access-profile-dot1x] quit
# 2) 认证模板引用
[SW] authentication-profile name dot1x
[SW-authen-profile-dot1x] dot1x-access-profile dot1x
[SW-authen-profile-dot1x] access-domain huawei.com
[SW-authen-profile-dot1x] quit
# 3) 接口引用
[SW] interface GigabitEthernet 0/0/3
[SW-GigabitEthernet0/0/3] authentication-profile dot1x
[SW-GigabitEthernet0/0/3] quit
```

EAP 终结（pap/chap）由设备与 RADIUS 交互；EAP 中继（eap）由 RADIUS 服务器处理（如 EAP-PEAP/EAP-TLS）。

## 6. Portal 认证

### 6.1 交换机/AC + 外置 Portal 服务器

```text
# Portal 服务器
[SW] web-auth-server portal
[SW-web-auth-server-portal] server-ip 172.21.10.78
[SW-web-auth-server-portal] port 50100
[SW-web-auth-server-portal] shared-key cipher Huawei@123
[SW-web-auth-server-portal] source-ip 172.21.10.61
[SW-web-auth-server-portal] url-template nce
[SW-web-auth-server-portal] quit
# URL 模板（重定向页面）
[SW] url-template name nce
[SW-url-template-nce] url https://172.21.10.78:19008/portal
[SW-url-template-nce] url-parameter redirect-url redirect-url user-ipaddress userip user-mac umac
[SW-url-template-nce] quit
# Portal 接入模板
[SW] portal-access-profile name portal
[SW-portal-access-profile-portal] web-auth-server portal direct
[SW-portal-access-profile-portal] quit
# 认证模板 + 接口引用
[SW] authentication-profile name auth_portal
[SW-authentication-profile-auth_portal] portal-access-profile portal
[SW-authentication-profile-auth_portal] access-domain default
[SW-authentication-profile-auth_portal] quit
```

内置 Portal（AC）：`portal local-server enable`、`portal local-server authentication-method pap`。

### 6.2 防火墙内置 Portal（身份认证）

```text
[FW] identity-management
[FW-identity-management] portal
[FW-identity-management-portal] portal enable
[FW-identity-management-portal] server https ip 172.16.20.2 port 8887
[FW-identity-management-portal] quit
# 本地认证用户
[FW] aaa
[FW-aaa] local-access-user user1
[FW-aaa-access-user-user1] password cipher Huawei@123
[FW-aaa-access-user-user1] service-type portal
[FW-aaa-access-user-user1] ucl-group staff
[FW-aaa-access-user-user1] quit
# 认证策略：触发 Portal
[FW] auth-policy
[FW-policy-auth] rule name policy_auth_01
[FW-policy-auth-rule-policy_auth_01] source-zone trust
[FW-policy-auth-rule-policy_auth_01] source-address 172.16.20.0 24
[FW-policy-auth-rule-policy_auth_01] action portal
```

## 7. MAC 认证（无客户端，以 MAC 为账号）

```text
[SW] mac-access-profile name m1
[SW-mac-access-profile-m1] mac-authen username macaddress format with-hyphen password cipher Huawei@123
[SW-mac-access-profile-m1] quit
[SW] authentication-profile name mac
[SW-authen-profile-mac] mac-access-profile m1
[SW-authen-profile-mac] access-domain huawei.com
[SW-authen-profile-mac] quit
```

终端 MAC 需在 RADIUS/本地存在对应用户；适合打印机、IP 电话等哑终端。

## 8. 免认证规则 free-rule

放行无需认证即可访问的资源（如 DNS、认证服务器）：

```text
[SW] free-rule-template name free_rule
[SW-free-rule-free_rule] free-rule 1 destination ip 172.21.10.78 mask 255.255.255.255
[SW-free-rule-free_rule] quit
# 在认证模板中引用
[SW-authen-profile-auth_portal] free-rule-template free_rule
```

## 9. 验证与排障

```text
<SW> display authentication-profile configuration
<SW> display access-user                    # 在线用户及认证方式
<SW> display domain [ huawei.com ]
<SW> display radius-server configuration
<SW> display web-auth-server configuration
# 调试（排障后关闭）
<SW> terminal monitor; <SW> terminal debugging
<SW> debugging portal event / message
<SW> debugging dot1x all
```

**常见问题**：
- 认证不通过：RADIUS 共享密钥、端口、NAS/源 IP 是否正确；服务器是否可达（`test-aaa` 可模拟测试）。
- Portal 不跳转：重定向 URL/url-template、web-auth-server、free-rule 是否放行了认证服务器；HTTPS 重定向证书。
- 802.1X 报文透传中间交换机：中间交换机端口需 `l2protocol-tunnel user-defined-protocol dot1x enable`，并避免 DHCP Snooping 等拦截。
