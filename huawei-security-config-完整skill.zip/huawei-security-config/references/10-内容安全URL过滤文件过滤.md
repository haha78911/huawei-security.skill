# 10 · 内容安全与行为管控

> 四类安全配置文件（profile），均在安全策略规则中引用：**URL 过滤（url-filter）、文件阻断（file-block）、内容/数据过滤（data-filter，基于关键字）、应用行为控制（app-control）**。

## 目录
1. URL 过滤
2. 文件阻断（文件过滤）
3. 内容过滤（关键字 data-filter）
4. 应用行为控制
5. 完整案例
6. 验证与排障

---

## 1. URL 过滤

```text
[FW] profile type url-filter name url_profile_01
[FW-profile-url-filter-url_profile_01] add whitelist url www.example1.com
[FW-profile-url-filter-url_profile_01] add blacklist url www.example3.com
[FW-profile-url-filter-url_profile_01] category pre-defined control-level medium  # 预定义分类管控级别
[FW-profile-url-filter-url_profile_01] https-filter enable                        # 过滤 HTTPS（SNI）
[FW-profile-url-filter-url_profile_01] quit
# 安全策略引用
[FW] security-policy
[FW-policy-security] rule name policy_sec_01
[FW-policy-security-rule-policy_sec_01] source-zone trust
[FW-policy-security-rule-policy_sec_01] destination-zone untrust
[FW-policy-security-rule-policy_sec_01] source-address 10.3.0.0 mask 255.255.255.0
[FW-policy-security-rule-policy_sec_01] profile url-filter url_profile_01
[FW-policy-security-rule-policy_sec_01] action permit
```

- 黑白名单优先级最高；预定义 URL 分类库需升级（`control-level` 为 high/medium/low）。

## 2. 文件阻断（文件过滤）

按文件类型/扩展名阻断上传或下载（如阻断可执行文件）：

```text
[FW] profile type file-block name exe
[FW-profile-file-block-exe] rule name exe
[FW-profile-file-block-exe-rule-exe] file-type pre-defined name EXE MSI RPM OCX A ELF
[FW-profile-file-block-exe-rule-exe] direction download        # upload/download/both
[FW-profile-file-block-exe-rule-exe] action block
[FW-profile-file-block-exe-rule-exe] quit
# 安全策略引用
[FW-policy-security] rule name game_filter
[FW-policy-security-rule-game_filter] profile file-block exe
[FW-policy-security-rule-game_filter] action permit
```

## 3. 内容过滤（关键字 data-filter）

先建关键字组，再在 data-filter 中引用，对文件/应用内容做关键字匹配（如身份证、敏感词）：

```text
# 关键字组
[FW] keyword-group name secret
[FW-keyword-group-secret] user-defined-keyword name secret
[FW-keyword-group-secret-keyword-secret] expression match-mode text Huawei
[FW-keyword-group-secret-keyword-secret] quit
# 内容（数据）过滤配置文件
[FW] profile type data-filter name secret
[FW-profile-data-filter-secret] rule name secret
[FW-profile-data-filter-secret-rule-secret] keyword-group name secret
[FW-profile-data-filter-secret-rule-secret] file-type all
[FW-profile-data-filter-secret-rule-secret] application all
[FW-profile-data-filter-secret-rule-secret] direction both
[FW-profile-data-filter-secret-rule-secret] quit
# 安全策略引用
[FW-policy-security] rule name policy_data
[FW-policy-security-rule-policy_data] profile data-filter secret
[FW-policy-security-rule-policy_data] action permit
```

## 4. 应用行为控制

控制具体应用的行为（如禁止 FTP 上传、限制 QQ、控制 HTTP POST）：

```text
[FW] profile type app-control name profile_appc
[FW-profile-app-control-profile_appc] ftp-control file direction upload action deny
[FW-profile-app-control-profile_appc] im-control qq action deny
# im-control qq account blacklist/whitelist <账号>；http 行为控制命令以版本为准
[FW-profile-app-control-profile_appc] quit
# 安全策略引用
[FW-policy-security] rule name policy1
[FW-policy-security-rule-policy1] profile app-control profile_appc
[FW-policy-security-rule-policy1] action permit
```

## 5. 完整案例

```text
# URL 过滤（见第1节）、文件阻断（见第2节）、内容过滤（见第3节）
[FW] security-policy
[FW-policy-security] rule name internet_access
[FW-policy-security-rule-internet_access] source-zone trust
[FW-policy-security-rule-internet_access] destination-zone untrust
[FW-policy-security-rule-internet_access] source-address 10.3.0.0 24
[FW-policy-security-rule-internet_access] profile url-filter url_profile_01
[FW-policy-security-rule-internet_access] profile file-block exe
[FW-policy-security-rule-internet_access] profile data-filter secret
[FW-policy-security-rule-internet_access] profile app-control profile_appc
[FW-policy-security-rule-internet_access] action permit
<FW> save
```

一条规则可叠加多个内容安全 profile；同时配置源 NAT 即可（见 02）。

## 6. 验证与排障

```text
<FW> display profile type url-filter
<FW> display profile type file-block
<FW> display profile type data-filter
<FW> display profile type app-control
<FW> display logbuffer          # 命中/阻断日志
```

- 不生效：确认安全策略规则确实引用了 profile、流量命中该规则（`display security-policy rule all` 看计数）。
- HTTPS 网站 URL 过滤无效：开启 `https-filter`，依赖 SNI；文件/内容过滤对加密流量需配合 SSL 解密（decryption-policy）。
- 预定义分类/应用识别不准：升级 URL 分类库与应用识别特征库。
