# 07 · IPSec VPN（站点到站点，IKE 自动协商）

> IPSec 在公网上为站点间建立加密隧道。主流方式：**IKE 自动协商（isakmp）**；另支持手工密钥（manual）与策略模板（template，总部接受动态分支）。

## 目录
1. 配置步骤总览
2. 感兴趣流 ACL
3. IPSec 安全提议
4. IKE 安全提议
5. IKE 对等体
6. IPSec 策略（isakmp / manual / template）
7. 接口应用与安全策略放行
8. NAT 豁免
9. 完整站点到站点案例
10. 验证与排障

---

## 1. 配置步骤总览

1. 高级 ACL 定义**感兴趣流**（哪些子网间流量走隧道）。
2. `ipsec proposal` 定义二阶段（IPSec SA）保护参数。
3. `ike proposal` 定义一阶段（IKE SA）保护参数。
4. `ike peer` 定义对端地址、预共享密钥、引用 ike proposal、NAT 穿越/DBD。
5. `ipsec policy ... isakmp` 组合 ACL + ipsec proposal + ike peer。
6. 出接口应用 `ipsec policy`；安全策略放行协议与隧道内流量；感兴趣流做 NAT 豁免。

## 2. 感兴趣流 ACL

```text
[FW] acl number 3500
[FW-acl4-advance-3500] rule permit ip source 172.16.30.0 0.0.0.255 destination 100.100.1.0 0.0.0.255
[FW-acl4-advance-3500] quit
```

- ACL 用通配符掩码（反掩码）；两端感兴趣流应**镜像对称**。
- 只有命中 permit 的流量才会触发/进入隧道。

## 3. IPSec 安全提议（二阶段）

```text
[FW] ipsec proposal 1
[FW-ipsec-proposal-1] encapsulation-mode tunnel        # tunnel（隧道，默认）/ transport
[FW-ipsec-proposal-1] transform esp                    # esp（加密+认证）/ ah（仅认证）
[FW-ipsec-proposal-1] esp authentication-algorithm sha2-256
[FW-ipsec-proposal-1] esp encryption-algorithm aes-256-gcm-128
[FW-ipsec-proposal-1] quit
```

- 两端 ESP/AH 算法、封装模式必须一致；使用 GCM（aes-256-gcm-128）时认证由 GCM 提供。

## 4. IKE 安全提议（一阶段）

```text
[FW] ike proposal 1
[FW-ike-proposal-1] encryption-algorithm aes-gcm-256
[FW-ike-proposal-1] authentication-algorithm sha2-256
[FW-ike-proposal-1] authentication-method pre-share   # 预共享密钥（或 rsa-signature）
[FW-ike-proposal-1] dh group14                        # 主模式密钥交换 DH 组
[FW-ike-proposal-1] integrity-algorithm hmac-sha2-256
[FW-ike-proposal-1] prf hmac-sha2-256
[FW-ike-proposal-1] quit
```

两端加密/认证/PRF/完整性算法、DH 组、认证方式须一致。

## 5. IKE 对等体

```text
[FW] ike peer 1
[FW-ike-peer-1] ike-proposal 1
[FW-ike-peer-1] remote-address 100.1.1.8              # 对端公网地址
[FW-ike-peer-1] pre-shared-key Huawei@123             # 两端一致
[FW-ike-peer-1] nat traversal                         # 存在 NAT 时使能 NAT 穿越
[FW-ike-peer-1] dpd type on-demand                    # 死 peer 检测（可选）
[FW-ike-peer-1] quit
```

NAT 穿越相关（视版本）：`ike nat-keepalive-timer interval 30`、`ipsec nat-traversal source-port 4510`。

## 6. IPSec 策略

### 6.1 isakmp（IKE 自动，主流）

```text
[FW] ipsec policy map1 10 isakmp
[FW-ipsec-policy-isakmp-map1-10] security acl 3500
[FW-ipsec-policy-isakmp-map1-10] proposal 1
[FW-ipsec-policy-isakmp-map1-10] ike-peer 1
[FW-ipsec-policy-isakmp-map1-10] quit
```

### 6.2 manual（手工密钥，无需 IKE，参数两端镜像）

```text
[FW] ipsec policy pl1 10 manual
[FW-ipsec-policy-manual-pl1-10] security acl 3001
[FW-ipsec-policy-manual-pl1-10] proposal pps1
[FW-ipsec-policy-manual-pl1-10] tunnel local 12.1.1.1
[FW-ipsec-policy-manual-pl1-10] tunnel remote 23.1.1.3
[FW-ipsec-policy-manual-pl1-10] sa spi outbound ah 12345
[FW-ipsec-policy-manual-pl1-10] sa spi inbound ah 54321
[FW-ipsec-policy-manual-pl1-10] sa string-key outbound ah simple hw123456
[FW-ipsec-policy-manual-pl1-10] sa string-key inbound ah simple hw654321
```

### 6.3 template（总部策略模板，接受分支动态地址/协商）

```text
[FW3] ipsec policy-template map1 10
[FW3-ipsec-policy-templet-map1-10] security acl 3500
[FW3-ipsec-policy-templet-map1-10] proposal 1
[FW3-ipsec-policy-templet-map1-10] ike-peer 1
[FW3-ipsec-policy-templet-map1-10] quit
[FW3] ipsec policy 1 10 isakmp template map1
```

## 7. 接口应用与安全策略放行

```text
# 出接口应用策略
[FW] interface GigabitEthernet 0/0/2
[FW-GigabitEthernet0/0/2] ipsec policy map1
[FW-GigabitEthernet0/0/2] quit
```

安全策略需放行：① 隧道协商/封装报文（IKE UDP 500、NAT-T UDP 4500、ESP 50、AH 51，源/目的为两端公网地址，区域 untrust↔local）；② 隧道内业务流量（源/目的为两端私网/业务网段）：

```text
[FW] security-policy
[FW-policy-security] rule name IPSec_OA
[FW-policy-security-rule-IPSec_OA] source-zone trust untrust
[FW-policy-security-rule-IPSec_OA] destination-zone untrust trust
[FW-policy-security-rule-IPSec_OA] source-address 172.16.30.0 mask 255.255.255.0
[FW-policy-security-rule-IPSec_OA] source-address 100.100.1.0 mask 255.255.255.0
[FW-policy-security-rule-IPSec_OA] destination-address 100.100.1.0 mask 255.255.255.0
[FW-policy-security-rule-IPSec_OA] destination-address 172.16.30.0 mask 255.255.255.0
[FW-policy-security-rule-IPSec_OA] action permit
[FW-policy-security-rule-IPSec_OA] quit
```

## 8. NAT 豁免（关键）

走隧道的感兴趣流**不能做源 NAT**，需在 nat-policy 中置于 NAT 规则之前并 `action no-nat`：

```text
[FW] nat-policy
[FW-policy-nat] rule name IPSec-deny
[FW-policy-nat-rule-IPSec-deny] source-zone trust
[FW-policy-nat-rule-IPSec-deny] destination-zone untrust
[FW-policy-nat-rule-IPSec-deny] destination-address 100.100.1.0 mask 255.255.255.0
[FW-policy-nat-rule-IPSec-deny] action no-nat
[FW-policy-nat-rule-IPSec-deny] quit
# 其余上网流量再做 easy-ip / 地址组（置于其后）
```

## 9. 完整站点到站点案例（分支 Branch → 总部 HQ）

```text
# 感兴趣流
[Branch-FW] acl 3000
[Branch-FW-acl4-advance-3000] rule permit ip source 192.168.14.0 0.0.0.255 destination 192.168.11.0 0.0.0.255
# IPSec 提议
[Branch-FW] ipsec proposal Branch
[Branch-FW-ipsec-proposal-Branch] encapsulation-mode tunnel
[Branch-FW-ipsec-proposal-Branch] transform esp
[Branch-FW-ipsec-proposal-Branch] esp authentication-algorithm sha2-256
[Branch-FW-ipsec-proposal-Branch] esp encryption-algorithm aes-256-gcm-128
[Branch-FW-ipsec-proposal-Branch] quit
# IKE 提议
[Branch-FW] ike proposal 10
[Branch-FW-ike-proposal-10] authentication-method pre-share
[Branch-FW-ike-proposal-10] encryption-algorithm aes-gcm-256
[Branch-FW-ike-proposal-10] dh group14
[Branch-FW-ike-proposal-10] integrity-algorithm hmac-sha2-256
[Branch-FW-ike-proposal-10] prf hmac-sha2-256
[Branch-FW-ike-proposal-10] quit
# IKE 对等体
[Branch-FW] ike peer HQ
[Branch-FW-ike-peer-HQ] ike-proposal 10
[Branch-FW-ike-peer-HQ] remote-address 100.1.35.3
[Branch-FW-ike-peer-HQ] pre-shared-key Huawei@123
[Branch-FW-ike-peer-HQ] quit
# IPSec 策略
[Branch-FW] ipsec policy map1 10 isakmp
[Branch-FW-ipsec-policy-isakmp-map1-10] security acl 3000
[Branch-FW-ipsec-policy-isakmp-map1-10] proposal Branch
[Branch-FW-ipsec-policy-isakmp-map1-10] ike-peer HQ
[Branch-FW-ipsec-policy-isakmp-map1-10] quit
# 出接口应用
[Branch-FW] interface GigabitEthernet 0/0/0
[Branch-FW-GE0/0/0] ipsec policy map1
[Branch-FW-GE0/0/0] quit
# 另需：安全策略放行、NAT 豁免、两端路由；总部用相同参数（可配 template）
```

## 10. 验证与排障

```text
<FW> display ike sa            # 一阶段 SA（无 = 一阶段失败）
<FW> display ipsec sa          # 二阶段 SA（有 IKE SA 无 IPSec SA = 二阶段失败）
<FW> display ipsec statistics  # 加解密/丢弃统计
# 用业务源地址触发隧道
<FW> ping -a 172.16.30.2 100.100.1.1
```

**分段排查**：
- **一阶段（IKE SA）不建立**：对端公网地址/路由可达性、预共享密钥一致、IKE proposal 参数一致、UDP 500/4500 是否放行；NAT 环境是否开启 nat traversal。
- **一阶段成功、二阶段（IPSec SA）失败**：ipsec proposal（封装模式/ESP-AH 算法）不一致、感兴趣流不匹配/不对称。
- **SA 正常但业务不通**：隧道内安全策略、NAT 豁免（是否被误 NAT）、两端到对端私网的路由、感兴趣流是否覆盖实际业务。
