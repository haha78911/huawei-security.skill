# 03 · 双机热备与高可靠性（HRP / VGMP）

> 两台防火墙一主一备（或双主），通过 **VGMP（VRRP 组管理协议）** 统一管理 VRRP 备份组、**HRP（热备冗余协议）** 完成状态与配置同步，实现故障切换。

## 目录
1. 关键概念与组网
2. 业务接口配置 VRRP 备份组
3. 心跳（HRP）接口与使能
4. 监控接口与主备角色
5. 配置/状态备份
6. BFD 与路由联动
7. 完整主备案例
8. 验证与排障

---

## 1. 关键概念与组网

- **VRRP 备份组**：在业务接口上配置虚拟 IP，主设备为 `active`、备为 `standby`。
- **VGMP**：把同一台设备上多个 VRRP 备份组捆绑为一个管理组，保证整机统一切换，避免半主半备。
- **HRP**：承载在心跳链路上，同步配置、会话（会话表/Server-map）、上下线用户等。
- 典型组网：FW1/FW2 上下行业务口分别接交换机（跑 VRRP），另有专门心跳口直连。

## 2. 业务接口配置 VRRP 备份组

```text
[FW1] interface GigabitEthernet 0/0/1
[FW1-GigabitEthernet0/0/1] ip address 10.3.0.1 255.255.255.0
[FW1-GigabitEthernet0/0/1] vrrp vrid 1 virtual-ip 10.3.0.3 255.255.255.0 active
[FW1-GigabitEthernet0/0/1] quit
[FW1] interface GigabitEthernet 0/0/2
[FW1-GigabitEthernet0/0/2] ip address 10.2.0.1 255.255.255.0
[FW1-GigabitEthernet0/0/2] vrrp vrid 2 virtual-ip 1.1.1.1 255.255.255.0 active
[FW1-GigabitEthernet0/0/2] quit
# 备机对应接口用 standby
[FW2-GigabitEthernet0/0/1] vrrp vrid 1 virtual-ip 10.3.0.3 255.255.255.0 standby
[FW2-GigabitEthernet0/0/2] vrrp vrid 2 virtual-ip 1.1.1.1 255.255.255.0 standby
```

> 同一设备的上下行 VRRP 组必须同为 active 或同为 standby（由 VGMP 保证）。业务接口加入安全区域的做法与单机相同。

## 3. 心跳（HRP）接口与使能

```text
# 主 FW1
[FW1] interface GigabitEthernet 0/0/3
[FW1-GigabitEthernet0/0/3] ip address 10.10.0.1 255.255.255.0
[FW1-GigabitEthernet0/0/3] quit
[FW1] firewall zone dmz
[FW1-zone-dmz] add interface GigabitEthernet 0/0/3
[FW1-zone-dmz] quit
[FW1] hrp interface GigabitEthernet 0/0/3 remote 10.10.0.2   # 指定心跳口及对端地址
[FW1] hrp authentication-key Admin@123                       # 心跳认证（两端一致）
[FW1] hrp enable                                             # 使能双机热备
[FW1] undo firewall packet-filter basic-protocol enable      # 放行 HRP 报文（视版本）
# 备 FW2
[FW2] hrp interface GigabitEthernet 0/0/3 remote 10.10.0.1
[FW2] hrp authentication-key Admin@123
[FW2] hrp enable
[FW2] undo firewall packet-filter basic-protocol enable
```

## 4. 监控接口与主备角色

```text
[FW1] hrp track interface GigabitEthernet 0/0/1    # 监控上行口，故障则降低优先级触发切换
[FW1] hrp track interface GigabitEthernet 0/0/2
# 手动指定角色（缺省由 VRRP 优先级/主动抢占决定）
[FW2] hrp standby-device     # 强制为备
[FW1] hrp active-device      # 强制为主
```

被监控接口/链路故障时，VGMP 优先级降低，主备发生倒换。

## 5. 配置 / 状态备份

- 使能 HRP 后，默认自动同步关键配置与会话；相关命令（视版本）：
  - `hrp auto-sync config`：自动备份配置。
  - `hrp mirror session enable` / `hrp session enable`：会话快速备份（业务不中断）。
  - `hrp sync [ config | connection-status ]`：手动立即备份。
- 主机提示符带 `HRP_M`、备机带 `HRP_S`，便于识别当前角色。

## 6. BFD 与路由联动

- 用 BFD 快速检测链路/对端故障，配合 VRRP/静态路由实现亚秒级切换：

```text
[R] bfd
[R] bfd 1 bind peer-ip 10.3.1.2 source-ip 4.4.4.2
[R-bfd-session-1] discriminator local 10
[R-bfd-session-1] discriminator remote 20
[R-bfd-session-1] min-rx-interval 300
[R-bfd-session-1] min-tx-interval 300
[R-bfd-session-1] detect-multiplier 3
[R-bfd-session-1] commit
# 静态路由联动 BFD
[R] ip route-static 100.1.1.0 255.255.255.0 10.0.12.2 track bfd-session 1
```

- 路由型双机（不使用 VRRP，上下行走 OSPF）：`hrp adjust ospf-cost enable`，让备机通告更大 cost，使流量优先走主机。

## 7. 完整主备案例（FW1 主 / FW2 备）

```text
# ===== FW1（主）=====
<HUAWEI> system-view
[HUAWEI] sysname FW1
[FW1] interface GigabitEthernet 0/0/1
[FW1-GigabitEthernet0/0/1] ip address 10.3.0.1 255.255.255.0
[FW1-GigabitEthernet0/0/1] vrrp vrid 1 virtual-ip 10.3.0.3 255.255.255.0 active
[FW1-GigabitEthernet0/0/1] quit
[FW1] interface GigabitEthernet 0/0/2
[FW1-GigabitEthernet0/0/2] ip address 10.2.0.1 255.255.255.0
[FW1-GigabitEthernet0/0/2] vrrp vrid 2 virtual-ip 1.1.1.1 255.255.255.0 active
[FW1-GigabitEthernet0/0/2] quit
[FW1] interface GigabitEthernet 0/0/3
[FW1-GigabitEthernet0/0/3] ip address 10.10.0.1 255.255.255.0
[FW1-GigabitEthernet0/0/3] quit
[FW1] firewall zone trust
[FW1-zone-trust] add interface GigabitEthernet 0/0/1
[FW1-zone-trust] quit
[FW1] firewall zone untrust
[FW1-zone-untrust] add interface GigabitEthernet 0/0/2
[FW1-zone-untrust] quit
[FW1] firewall zone dmz
[FW1-zone-dmz] add interface GigabitEthernet 0/0/3
[FW1-zone-dmz] quit
[FW1] hrp track interface GigabitEthernet 0/0/1
[FW1] hrp track interface GigabitEthernet 0/0/2
[FW1] hrp interface GigabitEthernet 0/0/3 remote 10.10.0.2
[FW1] hrp authentication-key Admin@123
[FW1] hrp enable
[FW1] undo firewall packet-filter basic-protocol enable
# ===== FW2（备）：业务口 IP 改为 .2，VRRP 用 standby，心跳 remote 指向 10.10.0.1，其余一致 =====
```

## 8. 验证与排障

```text
HRP_M[FW1] display hrp state          # HRP 状态（主/备、优先级、跟踪项）
HRP_M[FW1] display hrp interface      # 心跳口状态
HRP_M[FW1] display vrrp brief         # VRRP 组状态与虚拟 IP
HRP_M[FW1] display vrrp               # VRRP 详细（优先级/抢占）
HRP_M[FW1] display bfd session all    # BFD 会话
HRP_M[FW1] display firewall session table   # 会话（确认已同步）
```

**常见问题**：
- 两台都成主（双主/脑裂）：检查心跳链路是否 up、`hrp interface remote` 地址是否正确、认证密钥是否一致。
- 不切换：`hrp track` 是否监控了故障接口；BFD/VRRP 优先级与抢占配置。
- 配置不同步：确认 `hrp enable` 且自动同步开关打开；必要时 `hrp sync config` 手动备份。
