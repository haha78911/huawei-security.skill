# 08 · SSL VPN 与远程接入（USG 防火墙）

> SSL VPN 基于 HTTPS/TLS，远程用户用浏览器或客户端接入，无需安装专用网络层客户端。三类业务：**Web 代理、端口转发、网络扩展（network-extension，给远程用户分配内网 IP，可访问任意 IP 资源）**。

## 目录
1. 配置思路
2. 接口、区域与安全策略
3. 用户/用户组与授权
4. 地址池（网络扩展）
5. 虚拟网关与业务
6. 角色与资源授权
7. 完整网络扩展案例
8. 验证与排障

---

## 1. 配置思路

1. 接口配置 IP、加入区域（公网口 untrust、内网口 trust）。
2. 安全策略放行：untrust→local（访问 SSL VPN 网关 443）、untrust→trust（隧道/网络扩展业务）。
3. 配置 ucl-group（用户组）、local-access-user（远程接入用户）。
4. 配置 ip pool（网络扩展分配给远程用户的地址池）。
5. 创建 `virtual-gateway`（虚拟网关），配置监听地址端口与 network-extension 业务。
6. 配置角色（role）绑定用户组与可访问资源。

## 2. 接口、区域与安全策略

```text
[FW2] interface GigabitEthernet 0/0/2
[FW2-GE0/0/2] ip address 10.6.1.2 255.255.255.252
[FW2-GE0/0/2] service-manage ping permit
[FW2-GE0/0/2] quit
[FW2] interface GigabitEthernet 0/0/5
[FW2-GE0/0/5] ip address 172.16.10.1 255.255.255.0
[FW2-GE0/0/5] service-manage ping permit
[FW2-GE0/0/5] quit
[FW2] firewall zone trust
[FW2-zone-trust] add interface GigabitEthernet 0/0/5
[FW2-zone-trust] quit
[FW2] firewall zone untrust
[FW2-zone-untrust] add interface GigabitEthernet 0/0/2
[FW2-zone-untrust] quit
# 安全策略：访问网关本身
[FW2] security-policy
[FW2-policy-security] rule name ssl_gw
[FW2-policy-security-rule-ssl_gw] source-zone untrust
[FW2-policy-security-rule-ssl_gw] destination-zone local
[FW2-policy-security-rule-ssl_gw] destination-address 10.6.1.2 32
[FW2-policy-security-rule-ssl_gw] action permit
[FW2-policy-security-rule-ssl_gw] quit
# 安全策略：网络扩展用户访问内网
[FW2-policy-security] rule name ssl_oa
[FW2-policy-security-rule-ssl_oa] source-zone untrust
[FW2-policy-security-rule-ssl_oa] destination-zone trust
[FW2-policy-security-rule-ssl_oa] destination-address 172.16.10.0 24
[FW2-policy-security-rule-ssl_oa] action permit
[FW2-policy-security-rule-ssl_oa] quit
```

## 3. 用户 / 用户组与授权

```text
[FW2] ucl-group name group1
[FW2] aaa
[FW2-aaa] local-access-user User001
[FW2-aaa-access-user-User001] password cipher Huawei@123
[FW2-aaa-access-user-User001] ucl-group group1
[FW2-aaa-access-user-User001] quit
[FW2-aaa] quit
# 对接 AD 做授权（可选）
[FW-aaa] authorization-scheme ad
[FW-aaa-author-ad] authorization-mode ad
[FW-aaa] domain cce.com
[FW-aaa-domain-cce.com] authorization-scheme ad
```

## 4. 地址池（网络扩展）

远程用户网络扩展模式下从该地址池获取虚拟内网 IP：

```text
[FW2] ip pool ip_pool
[FW2-ip-pool-ip_pool] section 0 172.16.10.200 172.16.10.250
[FW2-ip-pool-ip_pool] quit
```

地址池网段应与内网路由打通（内网回程指向防火墙），并在安全策略中放行。

## 5. 虚拟网关与业务

```text
[FW2] virtual-gateway SSL_Gateway_1
[FW2-virtual-gateway-SSL_Gateway_1] service address 10.6.1.2 port 443
[FW2-virtual-gateway-SSL_Gateway_1] service
[FW2-virtual-gateway-SSL_Gateway_1-service] network-extension mode adapt
[FW2-virtual-gateway-SSL_Gateway_1-service] network-extension ip-pool ip_pool
[FW2-virtual-gateway-SSL_Gateway_1-service] network-extension keep-alive timeout 120
[FW2-virtual-gateway-SSL_Gateway_1-service] network-extension resource test ip-subnet 172.16.10.0 24
[FW2-virtual-gateway-SSL_Gateway_1-service] quit
[FW2-virtual-gateway-SSL_Gateway_1] quit
```

- `service address ... port 443`：网关监听地址与 HTTPS 端口（需证书，缺省自签名，可替换）。
- `network-extension mode adapt/...`：网络扩展模式；`ip-pool` 引用地址池；`resource` 声明可访问子网。
- Web 代理/端口转发业务在虚拟网关内以对应命令配置（命令以版本为准）。

## 6. 角色与资源授权

```text
[FW2] virtual-gateway SSL_Gateway_1
[FW2-virtual-gateway-SSL_Gateway_1] role Role1
[FW2-virtual-gateway-SSL_Gateway_1-role-Role1] group group1     # 关联用户组
[FW2-virtual-gateway-SSL_Gateway_1-role-Role1] resource test   # 授权可访问资源
[FW2-virtual-gateway-SSL_Gateway_1-role-Role1] quit
```

## 7. 完整网络扩展案例

按第 2→3→4→5→6 节顺序配置，核心为：

```text
# 接口/区域（见第2节）
# 用户与组
[FW2] ucl-group name group1
[FW2] aaa
[FW2-aaa] local-access-user User001
[FW2-aaa-access-user-User001] password cipher Huawei@123
[FW2-aaa-access-user-User001] ucl-group group1
# 地址池
[FW2] ip pool ip_pool
[FW2-ip-pool-ip_pool] section 0 172.16.10.200 172.16.10.250
# 虚拟网关
[FW2] virtual-gateway SSL_Gateway_1
[FW2-virtual-gateway-SSL_Gateway_1] service address 10.6.1.2 port 443
[FW2-virtual-gateway-SSL_Gateway_1] service
[FW2-virtual-gateway-SSL_Gateway_1-service] network-extension ip-pool ip_pool
[FW2-virtual-gateway-SSL_Gateway_1-service] network-extension resource test ip-subnet 172.16.10.0 24
[FW2-virtual-gateway-SSL_Gateway_1-service] quit
[FW2-virtual-gateway-SSL_Gateway_1] role Role1
[FW2-virtual-gateway-SSL_Gateway_1-role-Role1] group group1
[FW2-virtual-gateway-SSL_Gateway_1-role-Role1] resource test
<FW2> save
```

远程用户浏览器访问 `https://10.6.1.2`，登录后启用网络扩展，即可访问 172.16.10.0/24。

## 8. 验证与排障

```text
<FW> display virtual-gateway [ name ]          # 虚拟网关与业务状态
<FW> display access-user                       # 在线远程用户
<FW> display ip pool name ip_pool used         # 地址池分配
<FW> display firewall session table            # 会话
<FW> display logbuffer
```

**常见问题**：
- 打不开登录页：untrust→local 策略、443 端口、`service address` 监听、证书（浏览器告警需信任）。
- 登录后无法访问内网：网络扩展地址池、untrust→trust 策略是否放行地址池网段、内网回程路由是否指向防火墙、角色 resource 授权。
- 地址池耗尽：扩大 ip pool；用户异常占用可清理在线用户。
