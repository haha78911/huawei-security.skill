#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""华为安全配置命令库检索工具（零第三方依赖）。

用法：
  python3 kb.py topics                         列出全部主题
  python3 kb.py toc <tNN>                      列出某主题的节标题
  python3 kb.py search 关键词 [关键词...] [--topic tNN[,tNN]] [--limit N] [--full]
  python3 kb.py cmd <命令片段> [--topic tNN] [--limit N]   按命令行检索（输出命令及上下文）
  python3 kb.py section <gID>                  输出整节原文（gID 见搜索结果）

检索在 data/topics 下进行，不依赖网络。多关键词为 AND；标题命中加权排序。
"""
import argparse, json, os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
SEC_RE = re.compile(r"^@@SECTION\s+(.*)$")


def load_index():
    return json.load(open(os.path.join(DATA, "index.json"), encoding="utf-8"))


def parse_meta(line):
    meta = {}
    for part in line.split("|"):
        if "=" in part:
            k, v = part.split("=", 1)
            meta[k.strip()] = v.strip()
    return meta


def iter_sections(topic_filter=None):
    idx = load_index()
    tnames = {"%02d" % t["topic_id"]: t["name"] for t in idx["topics"]}
    for t in idx["topics"]:
        tid = f"t{t['topic_id']:02d}"
        if topic_filter and tid not in topic_filter:
            continue
        text = open(os.path.join(DATA, t["file"]), encoding="utf-8").read()
        blocks = text.split("@@SECTION ")
        for blk in blocks[1:]:
            first_nl = blk.find("\n")
            meta = parse_meta(blk[:first_nl])
            if not meta.get("id"):
                continue  # 非真正节标记（如文件头说明里出现的字面 @@SECTION）
            body = blk[first_nl + 1:]
            body = re.sub(r"\n@@END\s*$", "", body).rstrip("\n")
            meta["topic_name"] = tnames.get(meta.get("t", ""), "")
            yield meta, body


def snippet(body, kws, width=90, maxhits=3):
    low = body
    out = []
    for kw in kws:
        for m in re.finditer(re.escape(kw), low, re.IGNORECASE):
            a = max(0, m.start() - width); b = min(len(body), m.end() + width)
            seg = body[a:b].replace("\n", " ⏎ ")
            out.append(("…" if a else "") + seg + ("…" if b < len(body) else ""))
            if len(out) >= maxhits:
                return out
    return out


def score(meta, body, kws):
    title = meta.get("title", "").lower()
    bl = body.lower()
    s = 0
    for kw in kws:
        kl = kw.lower()
        if kl in title:
            s += 8
        cnt = bl.count(kl)
        if cnt == 0:
            return -1
        s += min(cnt, 6)
    # 命令密度小幅加权
    s += min(body.count("system-view"), 3)
    return s


def cmd_topics(v):
    if not v:
        return None
    return set(x.strip() for x in v.split(",") if x.strip())


def main():
    ap = argparse.ArgumentParser(description="华为安全配置命令库检索")
    sub = ap.add_subparsers(dest="action", required=True)

    sub.add_parser("topics")
    p_toc = sub.add_parser("toc"); p_toc.add_argument("topic")

    p_s = sub.add_parser("search")
    p_s.add_argument("kws", nargs="+")
    p_s.add_argument("--topic"); p_s.add_argument("--limit", type=int, default=12)
    p_s.add_argument("--full", action="store_true")

    p_c = sub.add_parser("cmd")
    p_c.add_argument("pattern")
    p_c.add_argument("--topic"); p_c.add_argument("--limit", type=int, default=20)

    p_sec = sub.add_parser("section"); p_sec.add_argument("gid")

    a = ap.parse_args()

    if a.action == "topics":
        idx = load_index()
        print(f"命令库：{idx['title']}\n")
        for t in idx["topics"]:
            print("  t%02d  %3d节 %5.1f万字  %s" % (t["topic_id"], t["sections"], t["chars"]/10000.0, t["name"]))
        return

    if a.action == "toc":
        tid = a.topic if a.topic.startswith("t") else f"t{int(a.topic):02d}"
        for meta, body in iter_sections({tid}):
            print(f"  [{meta.get('id')}] L{meta.get('level')} ({meta.get('kind')}) {meta.get('title')}")
        return

    if a.action == "section":
        gid = a.gid if a.gid.startswith("g") else f"g{a.gid}"
        for meta, body in iter_sections():
            if meta.get("id") == gid:
                print(f"# {meta.get('title')}  [t{meta.get('t')} {meta.get('topic_name')} / {meta.get('doc')}]")
                print(body)
                return
        print("未找到该节", file=sys.stderr); sys.exit(1)

    if a.action == "search":
        tf = cmd_topics(a.topic)
        ranked = []
        for meta, body in iter_sections(tf):
            sc = score(meta, body, a.kws)
            if sc >= 0:
                ranked.append((sc, meta, body))
        ranked.sort(key=lambda x: -x[0])
        ranked = ranked[:a.limit]
        if not ranked:
            print("未命中。可先用 `topics` 查看主题，或更换关键词。"); return
        for sc, meta, body in ranked:
            print(f"\n■ [{meta.get('id')}] {meta.get('title')}  (score={sc})")
            print(f"  t{meta.get('t')} {meta.get('topic_name')} · {meta.get('doc')} · {len(body)}字")
            if a.full:
                print(body)
            else:
                for sn in snippet(body, a.kws):
                    print("   " + sn)
        return

    if a.action == "cmd":
        tf = cmd_topics(a.topic)
        pat = re.compile(re.escape(a.pattern), re.IGNORECASE)
        hits = 0
        seen = set()
        for meta, body in iter_sections(tf):
            lines = body.split("\n")
            for i, ln in enumerate(lines):
                if pat.search(ln):
                    key = (meta.get("id"), ln.strip())
                    if key in seen:
                        continue
                    seen.add(key)
                    print(f"\n■ [{meta.get('id')}] {meta.get('title')}  (t{meta.get('t')} {meta.get('topic_name')})")
                    lo = max(0, i - 2); hi = min(len(lines), i + 3)
                    for j in range(lo, hi):
                        mark = ">>" if j == i else "  "
                        print(f"  {mark} {lines[j]}")
                    hits += 1
                    if hits >= a.limit:
                        return
        if hits == 0:
            print("未找到含该命令片段的命令行。")


if __name__ == "__main__":
    try:
        main()
    except BrokenPipeError:
        try:
            sys.stdout.close()
        except Exception:
            pass
