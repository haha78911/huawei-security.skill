---
name: huawei-security-config
description: 华为网络安全设备配置命令专家（HCIA/HCIP/HCIE-Security），覆盖 USG 防火墙、交换机、路由器的安全配置与排障。当用户需要配置、排查或迁移以下内容时使用：CLI 基础与设备管理、安全区域与安全策略、NAT（源/目的/服务器映射/SNAT）、双机热备 HRP、虚拟系统 vsys、流量管理与智能选路、入侵防御 IPS、反病毒 AV、AAA、RADIUS/HWTACACS、NAC（802.1X/Portal/MAC）、IPSec VPN、SSL VPN 远程接入、单包攻击与扫描防范、DDoS/CC 防护、URL 过滤、文件阻断、内容过滤、应用行为控制、WAF、交换安全（端口安全/隔离/DHCP Snooping/ARP）、路由协议安全与本机防攻击 cpu-defend、IPv6/ND/OSPFv3 安全、故障排查、应急响应，以及思科 IOS 到华为 VRP 的命令对照。典型触发词：华为/USG/防火墙/交换机/路由器、安全策略、放通、NAT、双机热备、IPSec/SSL VPN、准入认证、攻击防范、配置命令、命令对照、思科转华为。
---

# 华为安全配置命令

面向华为安全设备（USG 防火墙 / S 系列交换机 / AR 路由器，VRP）的配置、排障与命令迁移。所有命令均提取自离线《华为安全 Security 知识全书》，保持真实写法、不杜撰。

## 工作流

1. **识别设备与场景**：防火墙 / 交换机 / 路由器；要实现的功能或故障现象。
2. **读取对应 reference**：按下表选择 1 个最匹配的主题文档，获取命令速查、完整可运行案例与验证命令。
3. **需要更全原文时用 kb.py 检索**：核实某条命令的真实写法、参数或更多案例（见下）。
4. **给出完整配置**：按视图顺序组织，包含接口/区域、策略、NAT、路由等关联项；占位值（IP、密钥、接口号）明确标注由用户替换。
5. **附验证与排障命令**：配置后用 `display ...` 验证，并给常见问题定位方法。

> 命令在不同 VRP/设备版本间可能有差异。拿不准的命令用 `kb.py cmd` 核实，或提示以实际版本为准；不要凭空编造参数。

## references 导航

| 文档 | 覆盖内容 |
|---|---|
| [00-CLI基础与设备管理](references/00-CLI基础与设备管理.md) | 命令行视图、登录管理、管理员、文件/版本管理 |
| [01-防火墙安全区域与安全策略](references/01-防火墙安全区域与安全策略.md) | security-zone、security-policy 规则、默认动作 |
| [02-NAT地址转换](references/02-NAT地址转换.md) | 源 NAT、Easy-IP、NAT Server、目的 NAT |
| [03-双机热备HRP](references/03-双机热备HRP.md) | HRP、主备/负载分担、VGMP、监控与抢占 |
| [04-虚拟系统流量管理智能选路](references/04-虚拟系统流量管理智能选路.md) | vsys、带宽/限流、策略路由、智能选路 |
| [05-入侵防御与反病毒](references/05-入侵防御与反病毒.md) | IPS profile、签名集/例外、AV profile |
| [06-用户管理AAA与NAC](references/06-用户管理AAA与NAC.md) | AAA、RADIUS/HWTACACS、域、802.1X/Portal/MAC |
| [07-IPSec-VPN](references/07-IPSec-VPN.md) | 感兴趣流、IKE/IPSec 提议、ike-peer、策略、NAT 豁免 |
| [08-SSL-VPN远程接入](references/08-SSL-VPN远程接入.md) | 虚拟网关、网络扩展、地址池、角色授权 |
| [09-攻击防范与DDoS](references/09-攻击防范与DDoS.md) | 单包/扫描防范、Flood/CC、黑白名单、Anti-DDoS |
| [10-内容安全URL过滤文件过滤](references/10-内容安全URL过滤文件过滤.md) | url-filter、file-block、data-filter、app-control |
| [11-WAF与Web安全](references/11-WAF与Web安全.md) | WAF 部署、规则组/动作、虚拟补丁（Web 管理） |
| [12-交换安全](references/12-交换安全.md) | 端口安全/隔离、MAC、风暴、DHCP Snooping、ARP、uRPF |
| [13-路由安全与本机防攻击](references/13-路由安全与本机防攻击.md) | 协议认证、Keychain、GTSM、cpu-defend |
| [14-IPv6安全](references/14-IPv6安全.md) | IPv6、DHCPv6、ND 安全、VRRP6、OSPFv3、隧道 |
| [15-故障排查与应急响应](references/15-故障排查与应急响应.md) | 诊断命令、分段定位、PDCERF、主机排查、封堵 |
| [16-思科华为命令对照](references/16-思科华为命令对照.md) | IOS ↔ VRP 安全命令迁移对照 |

## kb.py 命令库检索（零依赖）

`scripts/kb.py` 在本地 `data/`（29 主题 / 1254 节 / 约 276 万字）检索，不占上下文、不依赖网络。

```bash
SK=/path/to/huawei-security-config
python3 $SK/scripts/kb.py topics                       # 列出全部主题
python3 $SK/scripts/kb.py toc t12                      # 某主题的节标题
python3 $SK/scripts/kb.py search 安全策略 源地址         # 多关键词 AND，标题加权
python3 $SK/scripts/kb.py search IPSec NAT豁免 --topic t12 --full
python3 $SK/scripts/kb.py cmd "ike peer"               # 按命令片段检索真实写法+上下文
python3 $SK/scripts/kb.py cmd "pre-shared-key" --topic t12
python3 $SK/scripts/kb.py section g657                 # 读取整节原文（gID 见搜索结果）
```

- **search**：定位讲某功能/原理的节，`--topic` 限定主题、`--full` 输出全文。
- **cmd**：核实命令真实写法与所在视图，优先用于不确定的命令。
- **section**：拿到节 id 后读取完整原文/案例。

## 使用要点

- 防火墙放通用 **安全策略（security-policy）**，不是 ACL；ACL 主要用于 IPSec 感兴趣流与流量匹配。
- 跨多特性的需求注意关联项：安全策略放行、NAT（及 IPSec 场景的 NAT 豁免）、路由、双机热备同步。
- 防火墙（USG）与交换机/路由器命令体系不同；对照表与版本支持以实际设备为准。
- 诊断/调试命令排障后及时关闭；生产环境变更先备份、一次一处并验证。
